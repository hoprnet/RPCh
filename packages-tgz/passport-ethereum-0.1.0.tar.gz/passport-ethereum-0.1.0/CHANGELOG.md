## [0.1.0] - 2022-06-07

- Initial release.

[0.1.0]: https://github.com/jaredhanson/passport-ethereum/releases/tag/v0.1.0
